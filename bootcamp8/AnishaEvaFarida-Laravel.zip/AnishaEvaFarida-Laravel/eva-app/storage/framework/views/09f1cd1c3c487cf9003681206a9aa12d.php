<?php $__env->startSection("container"); ?>
	<section class="section blog-wrap bg-gray">
		<a type="button" class="btn btn-success btn-sm float-right" href="/add">Add New Contact</a>
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="row">
						<div class="col-lg-12">
							<h4 class="mb-4">Contact List</h4>
							<table class="table table-sm">
								<thead>
									<tr>
										<th scope="col">No</th>
										<th scope="col">Name</th>
										<th scope="col">Email</th>
										<th scope="col">Phone Number</th>
										<th scope="col">Birthday</th>
										<th scope="col">Actions</th>
									</tr>
								</thead>
								<tbody>
											<th scope="row"></th>
											<td></td>
											<td></td>
											<td></td>
											<td></td>
											<td>
												<div>
													<span><a type="button" class="btn btn-outline-danger btn-sm px-2 py-1" href="/delete" onclick="return confirm('Delete it?')">Delete</a></span>
													<span><a class="btn btn-outline-primary btn-sm px-2 py-1" href="/edit">Edit</a></span>
												</div>
											</td>
										</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/anishaevaf/Downloads/bootcamp bflp/bootcamp8/eva-app/resources/views/listContact.blade.php ENDPATH**/ ?>